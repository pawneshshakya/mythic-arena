import React from "react";
import { MainLayout } from "../../components/layout/MainLayout";

const Promotions = () => {
  return (
    <MainLayout>
      <div className="p-8 text-dark">Promotions Page</div>
    </MainLayout>
  );
};

export default Promotions;
