import React from "react";

const HowToPlay = () => {
  return <div>HowToPlay</div>;
};

export default HowToPlay;
